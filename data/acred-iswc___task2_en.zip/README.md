This folder contains predictions for the [Clef'18 Factchecking Lab, Task 2](http://alt.qcri.org/clef2018-factcheck/) 
**test set**, computed using the [acred](https://github.com/rdenaux/acred) system, as described in our paper 
[Linked Credibility Reviews for Explainable Misinformation Detection](https://arxiv.org/abs/2008.12742)

The predictions with prefix `contrastive1` correspond to the basic `acred` implementation described in the paper, 
while predictions with prefix `primary` correspond to the improved `acred+` implementation.

Note that our [github repository](https://github.com/rdenaux/acred) is slightly modified as we removed some 
dependencies to proprietary software. As of September 6 2020, this version of acred achieves 0.6619 MAE, 
which is right in between acred and acred+. Please, refer to 
[our reproducibility instructions](https://github.com/rdenaux/acred/blob/master/ISWC-reproducibility.md) for 
more information on how to run the Clef'18 Task2 scorer.